package dbhw;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

public class Person {
    
    private boolean hasAddress;
    Address address;
    private UUID id;  //because Integer can be null, but int cannot be null
    private String firstName;
    private String lastName;

    public Person(String firstName, String lastName) {
        id = UUID.randomUUID();
        this.firstName = firstName;
        this.lastName = lastName;
        
    }
    
    public Person() {
        
    }
    
    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    // Function first checks to make sure if either the First or Last name are null
    // Next it generates a string that is the SQL command to insert the new entry. It looks like:
    
    // INSERT INTO person (id, first_name, last_name) VALUES('UUID1','John','Smith');
    
    // Where person is the table inside of the Database and the values are just an example
    // Then it executes the new SQL command and adds the entry to the database
    public void save(Statement statement) throws SQLException {
        
        if(id == null || firstName == null || lastName == null 
                      || firstName.equals("") || lastName.equals("")) {
            throw new RuntimeException("Invalid (ID, First Name, Last Name)");
        }
        
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("INSERT INTO person (id, first_name, last_name) VALUES (")
                .append("'").append(id).append("','")
                .append(firstName).append("','")
                .append(lastName).append("');");
        
        //This is the command required to send our new string
        // statement was originally created in DBUI.java and handles
        //  sending SQL statements to the DataBase
        statement.executeUpdate(stringBuilder.toString());
    }
    
    //This is the function used to remove a Person entry
    // You pass through the ID of the person and statement (handles SQL statements)
    // A string is created to make up the new SQL statement which looks like:
    
    // DELETE FROM person WHERE id='UUID1';
    
    // Where again person is the table inside of the database, and the id is the Person's ID from above
    // This would technically remove John Smith that was added above if we executed these commands
    public static void delete(UUID id, Statement statement) throws SQLException {
        StringBuilder stringBuilder = new StringBuilder();
        
        stringBuilder.append("DELETE FROM person WHERE id='")
                .append(id.toString()).append("';");
        
        System.out.println("Deleted Person");
        
        // sends the SQL statement created above to the database
        statement.execute(stringBuilder.toString());
    }
    
    //This function is used when the main form is first created to list the entries
    // This goes through all of the entries saved into the database
    // For each entry, it creates a new Person and adds it to the list that is displayed
    
    public static List<Person> getAllPeople(Statement statement) throws SQLException {
        List<Person> people = new LinkedList();
        
        //This command generates a set of each entry from the person table in the database
        // SELECT * FROM person
        // This means that it selects each entry as well as all of the data for it.
        // If you used: "SELECT first_name FROM person" it would select only the information for the first name of each entry
        
        ResultSet resultSet = statement.executeQuery("SELECT * FROM person");
        
        // This loop goes through each entry in the set from above and generates a new instance of the Person class
        // resu
        while(resultSet.next()) {
            Person person = new Person();
            person.setId(UUID.fromString(resultSet.getString("id")));    
            // the set includes the function .getString() where first_name is the rowid in the database
            person.setFirstName(resultSet.getString("first_name"));     //row: first_name  table: person
            person.setLastName(resultSet.getString("last_name"));       //row: last_name   table: person
            
            people.add(person);
        }
        
        return people;
    }
    
    public void setAddress(Address address) {
        hasAddress = true;
        this.address = address;
    }
    
    @Override
    public String toString() {
        if (hasAddress)
            return address.toString();
        else
            return firstName + "     " + lastName + "     "; //+ address.toString();
        
    }
    
    public String toJSON() {
        return firstName + " " + lastName + " : " + id.toString();
    }
}


