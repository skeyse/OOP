/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbhw;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import org.flywaydb.core.Flyway;

//Program designed to keep a database of people and their addresses
// Form is designed to display the list of entries and makes the entries clickable.
// You are able to add and delete people as well as add and delete an address for each person
// Each entry shows a Unique User ID which is just a second form of identification (it's usually hidden)
// 
public class DBUI extends javax.swing.JFrame {
    
        //You can ignore these 3 lines
        File file = new File("./database.json");
        DefaultListModel dlm = new DefaultListModel();
        public static boolean edit = false;
    
    public DBUI() throws ClassNotFoundException, SQLException {
        initComponents();
        //For GUI
        personList.setModel(dlm);
        
        // This loads the class for JDBC (Java Database Connectivity)
        Class.forName("org.sqlite.JDBC");
        
        // This creates the connection between the program and the database
        Connection connection = DriverManager.getConnection(DB_NAME);
        // statement is used a lot, and is how SQL statements are sent from the program to the Database
        statement = connection.createStatement();
        
        
    }
    
    //This is the database, the first 2 are how we're using SQL and the last is just the file name
    private static final String DB_NAME = "jdbc:sqlite:seankeyse.db";
    // Initializing the statement that's declared above
    static Statement statement;
    private List<Person> people = new LinkedList<>();
   
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        personList = new javax.swing.JList<>();
        addPerson = new javax.swing.JButton();
        deletePerson = new javax.swing.JButton();
        addAddress = new javax.swing.JButton();
        deleteAddress = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });

        personList.setModel(new javax.swing.AbstractListModel<Object>() {
            String[] strings = { "list" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        personList.setVisibleRowCount(25);
        personList.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                personListFocusGained(evt);
            }
        });
        jScrollPane1.setViewportView(personList);

        addPerson.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        addPerson.setText("Add Person");
        addPerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPersonActionPerformed(evt);
            }
        });

        deletePerson.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        deletePerson.setText("Delete Person");
        deletePerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePersonActionPerformed(evt);
            }
        });

        addAddress.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        addAddress.setText("Add Address");
        addAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addAddressActionPerformed(evt);
            }
        });

        deleteAddress.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        deleteAddress.setText("Delete Address");
        deleteAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteAddressActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(addPerson)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(deletePerson)
                        .addGap(144, 144, 144)
                        .addComponent(addAddress)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(deleteAddress)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(addPerson, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(deletePerson, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(deleteAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(addAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addPersonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPersonActionPerformed
        // TODO add your handling code here:
        
        PersonForm personForm;
        try {
            personForm = new PersonForm();
            personForm.setVisible(true);
            
        } catch (SQLException ex) {
            Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
    }//GEN-LAST:event_addPersonActionPerformed

    private void deletePersonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePersonActionPerformed
        // TODO add your handling code here:
        
        int row = personList.getSelectedIndex();
        try {
            people = Person.getAllPeople(statement);
            Person.delete(people.get(row).getId(), statement);
            getAllInfo();
        } catch (SQLException ex) {
            Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
        }        
        
    }//GEN-LAST:event_deletePersonActionPerformed

    private void addAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addAddressActionPerformed
        // TODO add your handling code here:
        int row = personList.getSelectedIndex();

        AddressForm addressForm;
        try { 
            people = Person.getAllPeople(statement);
            addressForm = new AddressForm();
            addressForm.person_id = people.get(row).getId();
            addressForm.setVisible(true);
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }//GEN-LAST:event_addAddressActionPerformed

    private void deleteAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteAddressActionPerformed
        // TODO add your handling code here:
        int row = personList.getSelectedIndex();
        
        try {
            people = Person.getAllPeople(statement);
            Address.delete(people.get(row).getId(), statement);
            getAllInfo();
        } catch (SQLException ex) {
            Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteAddressActionPerformed

    private void personListFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_personListFocusGained

    }//GEN-LAST:event_personListFocusGained

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained

    }//GEN-LAST:event_formFocusGained

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus
            try {
                // TODO add your handling code here:
                getAllInfo();
            } catch (SQLException ex) {
                Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_formWindowGainedFocus

    /**
     * @param args the command line arguments
     */

    
    public static void main(String args[]) throws ClassNotFoundException, SQLException {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DBUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DBUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DBUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DBUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    
                    //Initializing the JDBC Class as done above
                    Class.forName("org.sqlite.JDBC");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                //Flyway was the DB migration tool that we used.  There are probably others
                Flyway flyway = new Flyway();
        
                // Sets the database to ours, the next 2 empty strings are for username and password if it's a protected database
                flyway.setDataSource(DB_NAME, "", "");
                // Verifies that the Database's version hasn't changed
                flyway.setBaselineOnMigrate(true);
                // This is the other package in this project that's used to create the actual Database and its tables
                flyway.setLocations("dbhw.db.migration");
                // Starts the migration process from the database to our program.
                flyway.migrate();
                
                // For the GUI
                try {
                    new DBUI().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(DBUI.class.getName()).log(Level.SEVERE, null, ex);
                }
             
                
            }
            
        });
    }
    
    public static String getDBName() {
        return DB_NAME;
        
    }

    // Function to retrieve information for every entry in the database
    // This is just used to display all of the information in the GUI properly
    public void getAllInfo() throws SQLException {
        dlm.clear();
        ResultSet resultSet = statement.executeQuery(
                "SELECT * FROM person "
                        + "LEFT OUTER JOIN address ON address.user_id = person.id"
                  
                        // This line shows how the two tables in the database are linked.
                        // LEFT OUTER JOIN is used to add the Address information related to each Person and create one full entry
                        // It matches up the UUID of each Person to the user_id associated with each Address
                        // If the two ID's match, they're joined into one full result in the set
                        // If there's no match, the street and zip rows in the address table are just set to null
        );
        
        //This loop goes through each result in resultSet above to get the necessary information
        //resultSet.getString uses the row_id to pull the right information from the resultset
        while (resultSet.next()) {
            StringBuilder sb = new StringBuilder();
            
            // This is the id in the person table, which is equal to the user_id in the address table
            sb.append(resultSet.getString("id")).append("     ")
            .append(resultSet.getString("first_name")).append("     ")   // row: first_name  table: person
            .append(resultSet.getString("last_name")).append("     ")    // row: last_name   table: person
            .append(resultSet.getString("street")).append("     ")       // row: street      table: address
            .append(resultSet.getString("zip_code"));                    // row: zip_code    table: address
            
            // adds element to the list in the GUI
            dlm.addElement(sb);
        }
        
        
    }
    
    public void loadJSON(File file) {
        
    }
    
    public static boolean getEdit() {
        return edit;
                }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addAddress;
    private javax.swing.JButton addPerson;
    private javax.swing.JButton deleteAddress;
    private javax.swing.JButton deletePerson;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<Object> personList;
    // End of variables declaration//GEN-END:variables

}
